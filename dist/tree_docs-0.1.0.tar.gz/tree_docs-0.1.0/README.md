# 🌳 TreeDocs

[![PyPI version](https://badge.fury.io/py/tree-docs.svg)](https://badge.fury.io/py/tree-docs)
[![Python 3.8+](https://img.shields.io/badge/python-3.8+-blue.svg)](https://www.python.org/downloads/)
[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](https://opensource.org/licenses/MIT)
[![Code style: black](https://img.shields.io/badge/code%20style-black-000000.svg)](https://github.com/psf/black)

Gerador automático de árvore de diretórios com emojis e comentários para documentação em Markdown.

## ✨ Features

- 🚀 **Geração automática** da estrutura de diretórios
- 🎨 **Emojis** para identificar tipos de arquivos
- 📝 **Comentários** explicativos para pastas e arquivos
- 🎯 **Alinhamento** profissional dos comentários
- 🔧 **Altamente configurável**
- 💻 **CLI** e **API Python** disponíveis
- 📦 **Zero dependências** externas

## 📦 Instalação

### Via pip (recomendado)

```bash
pip install tree-docs